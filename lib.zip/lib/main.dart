import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'data/datasource/producto_api_datasource.dart';
import 'data/repositories/producto_repository_impl.dart';
import 'domain/usecases/create_producto_usecase.dart';
import 'domain/usecases/delete_producto_usecase.dart';
import 'domain/usecases/get_productos_usecase.dart';
import 'domain/usecases/update_producto_usecase.dart';
import 'presentation/routes/app_routes.dart';
import 'presentation/viewmodels/producto_viewmodel.dart';

void main() {
  // Inyección de dependencias
  final dataSource = ProductoApiDataSource();
  final repo = ProductoRepositoryImpl(dataSource);
  final getProductosUseCase = GetProductosUseCase(repo);
  final createProductoUsecase = CreateProductoUsecase(repo);
  final updateProductoUsecase = UpdateProductoUsecase(repo);
  final deleteProductoUsecase = DeleteProductoUsecase(repo);

  runApp(MyApp(
    getProductosUseCase: getProductosUseCase,
    createProductoUsecase: createProductoUsecase,
    updateProductoUsecase: updateProductoUsecase,
    deleteProductoUsecase: deleteProductoUsecase,
  ));
}

class MyApp extends StatelessWidget {
  final GetProductosUseCase getProductosUseCase;
  final CreateProductoUsecase createProductoUsecase;
  final UpdateProductoUsecase updateProductoUsecase;
  final DeleteProductoUsecase deleteProductoUsecase;

  const MyApp({
    super.key,
    required this.getProductosUseCase,
    required this.createProductoUsecase,
    required this.updateProductoUsecase,
    required this.deleteProductoUsecase,
  });

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => ProductoViewModel(
            usecase: getProductosUseCase,
            createProductosUsecase: createProductoUsecase,
            updateUsecase: updateProductoUsecase,
            deleteUsecase: deleteProductoUsecase,
          )..cargarProductos(),
        ),
      ],
      child: MaterialApp(
        title: "Consumo API Flutter",
        routes: AppRoutes.routes,
      ),
    );
  }
}
