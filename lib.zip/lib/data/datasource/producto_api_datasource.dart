import 'dart:convert';
import 'dart:developer';
import 'package:http/http.dart' as http;
import 'base_datasource.dart';
import '../models/producto_model.dart';

class ProductoApiDataSource implements BaseDataSource {
  final String baseURL = "http://10.0.2.2:3000/api/productos/";

  @override
  Future<List<ProductoModel>> fetchProductos() async {
    final uri = Uri.parse(baseURL);
    final resp = await http.get(uri);

    if(resp.statusCode != 200){
      throw Exception("Error al obtener datos de la api");
    }

    final List data = json.decode(resp.body);
    return data.map((item) => ProductoModel.fromJson(item)).toList();
  }

  @override
  Future<ProductoModel> createProducto(Map<String, dynamic> data) async {
    final resp = await http.post(
      Uri.parse(baseURL),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(data),
    );

    if(resp.statusCode != 201){
      throw Exception("Error al crear producto");
    }

    return ProductoModel.fromJson(json.decode(resp.body));
  }

  @override
  Future<ProductoModel> updateProducto(String id, Map<String, dynamic> data) async {
    final resp = await http.put(
      Uri.parse("$baseURL$id"),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(data),
    );

    log("UPDATE STATUS CODE: ${resp.statusCode}");
    log("UPDATE BODY: ${resp.body}");

    if(resp.statusCode != 200){
      throw Exception("Error al actualizar producto");
    }

    return ProductoModel.fromJson(json.decode(resp.body));
  }

  @override
  Future<bool> deleteProducto(String id) async {
    final resp = await http.delete(Uri.parse("$baseURL$id"));
    log("DELETE STATUS CODE: ${resp.statusCode}");
    return resp.statusCode == 200;
  }
}
