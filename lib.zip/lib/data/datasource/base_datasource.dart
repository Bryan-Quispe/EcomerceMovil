// Este Solo se encarga de enviar y extraer datos, no tiene nada de lógica
import '../models/producto_model.dart';

abstract class BaseDataSource {
  Future<List<ProductoModel>> fetchProductos();
  Future<ProductoModel> createProducto(Map<String, dynamic> data);
  Future<ProductoModel> updateProducto(String id, Map<String, dynamic> data);
  Future<bool> deleteProducto(String id);
}
