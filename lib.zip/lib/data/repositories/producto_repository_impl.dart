import '../../domain/entities/producto_entity.dart';
import '../datasource/base_datasource.dart';
import '../models/producto_model.dart';
import 'base_repository.dart';

class ProductoRepositoryImpl implements BaseRepository{
  final BaseDataSource ds;

  ProductoRepositoryImpl(this.ds);

  //create
  @override
  Future<List<ProductoEntity>> getProductos() {
    return ds.fetchProductos();
  }

  @override
  Future<ProductoEntity> createProductos(ProductoEntity p) {
    return ds.createProducto({
      "nombre": p.nombre,
      "precio": p.precio,
      "stock": p.stock,
      "categoria": p.categoria
    });
  }

  @override
  Future<ProductoEntity> updateProductos(String id, ProductoEntity p) {
    return ds.updateProducto(id,{
      "nombre": p.nombre,
      "precio": p.precio,
      "stock": p.stock,
      "categoria": p.categoria,
    });
  }

  @override
  Future<bool> deleteProductos(String id) {
    return ds.deleteProducto(id);
  }


}