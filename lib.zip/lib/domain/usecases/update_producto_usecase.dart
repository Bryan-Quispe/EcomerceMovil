// Es el segundo paso, definir el caso de uso
//Lo que se va a hacer en este archivo es obtener la lista de todos los productos desde la api
import '../entities/producto_entity.dart';
import '../../data/repositories/base_repository.dart';

class UpdateProductoUsecase {
  final BaseRepository repository;

  UpdateProductoUsecase(this.repository);

  //Mediante Future traemos el producto entity
  Future<ProductoEntity> call(String id, ProductoEntity p){
    return repository.updateProductos(id, p);
  }
}

