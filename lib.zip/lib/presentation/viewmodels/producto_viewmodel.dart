import 'package:pry_consumo_api_rest1/domain/usecases/create_producto_usecase.dart';

import '../../domain/entities/producto_entity.dart';
import '../../domain/usecases/delete_producto_usecase.dart';
import '../../domain/usecases/get_productos_usecase.dart';
import '../../domain/usecases/update_producto_usecase.dart';
import 'base_viewmodel.dart';

class ProductoViewModel extends BaseViewModel {
  final GetProductosUseCase usecase;
  final CreateProductoUsecase createProductosUsecase;
  final UpdateProductoUsecase updateUsecase;
  final DeleteProductoUsecase deleteUsecase;

  List<ProductoEntity> productos = [];

  ProductoViewModel(
  {   required this.usecase,
      required this.createProductosUsecase,
      required this.updateUsecase,
      required this.deleteUsecase});

  //cargar productos
  Future<void> cargarProductos() async {
    setLoading(true);
    productos = await usecase();
    setLoading(false);
  }

  //crear productos
  Future<void> agregarProductos(ProductoEntity p) async {
    await createProductosUsecase(p);
     await cargarProductos();

  }

  //modificar producto
  Future<void> editarProductos(ProductoEntity p, String id) async {
    await updateUsecase(id, p);
    await cargarProductos();

  }

  //eliminar producto
  Future<void> eliminarProductos(String id) async {
    await deleteUsecase(id);
    await cargarProductos();


  }
}
