import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../domain/entities/producto_entity.dart';
import '../viewmodels/producto_viewmodel.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<ProductoViewModel>();

    return Scaffold(
      appBar: AppBar(title: const Text("Productos")),
      body: vm.loading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: vm.productos.length,
              itemBuilder: (_, i) {
                final p = vm.productos[i];
                return ListTile(
                  title: Text(p.nombre),
                  subtitle: Text("Precio: \$${p.precio}"),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit),
                        onPressed: () => _mostrarDialogo(context, vm, p),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () {
                          showDialog(
                              context: context,
                              builder: (context) => AlertDialog(
                                    title: const Text('Confirmar eliminación'),
                                    content: Text(
                                        '¿Estás seguro de que quieres eliminar ${p.nombre}?'),
                                    actions: [
                                      TextButton(
                                        onPressed: () =>
                                            Navigator.pop(context),
                                        child: const Text('Cancelar'),
                                      ),
                                      TextButton(
                                        onPressed: () {
                                          vm.eliminarProductos(p.id);
                                          Navigator.pop(context);
                                        },
                                        child: const Text('Eliminar'),
                                      ),
                                    ],
                                  ));
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _mostrarDialogo(context, vm, null),
        child: const Icon(Icons.add),
      ),
    );
  }

  void _mostrarDialogo(
      BuildContext context, ProductoViewModel vm, ProductoEntity? p) {
    final nombreController = TextEditingController(text: p?.nombre ?? '');
    final precioController = TextEditingController(text: p?.precio.toString() ?? '');
    final stockController = TextEditingController(text: p?.stock.toString() ?? '');
    final categoriaController = TextEditingController(text: p?.categoria ?? '');

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(p == null ? "Nuevo Producto" : "Editar Producto"),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nombreController,
                decoration: const InputDecoration(labelText: "Nombre"),
              ),
              TextField(
                controller: precioController,
                decoration: const InputDecoration(labelText: "Precio"),
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
              ),
              TextField(
                controller: stockController,
                decoration: const InputDecoration(labelText: "Stock"),
                keyboardType: TextInputType.number,
              ),
              TextField(
                controller: categoriaController,
                decoration: const InputDecoration(labelText: "Categoría"),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancelar"),
          ),
          ElevatedButton(
            onPressed: () {
              final nombre = nombreController.text;
              final precio = double.tryParse(precioController.text);
              final stock = int.tryParse(stockController.text);
              final categoria = categoriaController.text;

              if (nombre.isEmpty || precio == null || stock == null || categoria.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Por favor, rellena todos los campos con valores válidos.')),
                );
                return;
              }

              if (p == null) {
                final newProduct = ProductoEntity(
                    id: '', 
                    nombre: nombre,
                    precio: precio,
                    stock: stock,
                    categoria: categoria);
                vm.agregarProductos(newProduct);
              } else {
                final updatedProduct = ProductoEntity(
                    id: p.id,
                    nombre: nombre,
                    precio: precio,
                    stock: stock,
                    categoria: categoria);
                vm.editarProductos(updatedProduct, p.id);
              }

              Navigator.pop(context);
            },
            child: const Text("Guardar"),
          ),
        ],
      ),
    );
  }
}
